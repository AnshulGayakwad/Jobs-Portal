package entitybeans;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="jobdetails")
public class jobdetails 
{
	@Id
	@Column(name="jobid")
	private String jobid;
	
	@Column(name="jobname")
	private String jobname;
	
	@Column(name="skills")
	private String skills;
	
	@Column(name="location")
	private String location;
	
	@Column(name="packages")
	private double packages;
	
	@Column(name="jobdate")
	private String jobdate;
	
	@Column(name="vacancy")
	private String vacancy;

	public String getJobid() {
		return jobid;
	}

	public void setJobid(String jobid) {
		this.jobid = jobid;
	}

	public String getJobname() {
		return jobname;
	}

	public void setJobname(String jobname) {
		this.jobname = jobname;
	}

	public String getSkills() {
		return skills;
	}

	public void setSkills(String skills) {
		this.skills = skills;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public double getPackages() {
		return packages;
	}

	public void setPackages(double packages) {
		this.packages = packages;
	}

	public String getJobdate() {
		return jobdate;
	}

	public void setJobdate(String jobdate) {
		this.jobdate = jobdate;
	}

	public String getVacancy() {
		return vacancy;
	}

	public void setVacancy(String vacancy) {
		this.vacancy = vacancy;
	}
	
	
	
	
}
