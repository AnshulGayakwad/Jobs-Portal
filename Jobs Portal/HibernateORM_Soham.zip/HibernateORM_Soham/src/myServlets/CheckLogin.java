package myServlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.Query;

import entitybeans.userlogin;

/**
 * Servlet implementation class CheckLogin
 */
@WebServlet("/CheckLogin")
public class CheckLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CheckLogin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		
		PrintWriter out= response.getWriter();
		response.setContentType("text/html");
		
		String userid=request.getParameter("uid");
		String pswd=request.getParameter("pass");
		String usertype="";
		
		try
		{

			Configuration cfg=new Configuration().configure();
			SessionFactory sf=cfg.addAnnotatedClass(userlogin.class).buildSessionFactory();
			Session ses=sf.getCurrentSession();
			ses.beginTransaction();
			
			Query q=ses.createQuery("from userlogin where userid= :uid and pswd= :pass");
			q.setParameter("uid", userid);
			q.setParameter("pass", pswd);
			
			List lst=q.getResultList();
			if(lst.size()>0)
			{
				userlogin obj=(userlogin) lst.get(0);
				usertype = obj.getUsertype();
				
				HttpSession sessoinTracking=request.getSession(true);
				sessoinTracking.setAttribute("userid", userid);
				
			   if(usertype.equals("employer"))
			   {
				   response.sendRedirect("employer.jsp");
			   }
			   else
			   {
				   response.sendRedirect("candidate.jsp");
			   }
			}
			else
			{
				response.sendRedirect("Failure.jsp");
			}
		}
		
		catch(Exception e)
		{
			out.println(e);
			response.sendRedirect("Failure.jsp");
		}
	}

}
