package myServlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import entitybeans.jobdetails;

/**
 * Servlet implementation class modifyjob
 */
@WebServlet("/modifyjob")
public class modifyjob extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public modifyjob() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		PrintWriter out= response.getWriter();
		response.setContentType("text/html");
		
		
		String jobid=request.getParameter("jobid");
		String jobname=request.getParameter("jobname");
		String location=request.getParameter("location");
		double packages=Double.parseDouble(request.getParameter("package"));
		String jobdate=request.getParameter("jobdate");
		String skills=request.getParameter("skills");
		String vacancy=request.getParameter("vacancy");
		
		
		try
		{
			Configuration cfg=new Configuration().configure();
			SessionFactory sf=cfg.addAnnotatedClass(jobdetails.class).buildSessionFactory();
			Session ses=sf.getCurrentSession();
			ses.beginTransaction();
			
			Query q=ses.createQuery("from jobdetails where jobid= :jobid");
			q.setParameter("jobid", jobid);
			
			List lst=q.getResultList();
			if(lst.size()>0)
			{
				System.out.println("correct jobid");
				
				Query qu=ses.createQuery("update jobdetails set skills=:skills, location=:location, packages=:packages, jobdate=:jobdate, vacancy=:vacancy, jobname=:jobname where jobid=:jobid");
				qu.setParameter("skills",skills);
				qu.setParameter("location",location);
				qu.setParameter("packages",packages);
				qu.setParameter("jobdate",jobdate);
				qu.setParameter("vacancy",vacancy);
				qu.setParameter("jobname",jobname);
				qu.setParameter("jobid",jobid);
				int i=qu.executeUpdate();
				ses.getTransaction().commit();
				if(i>0)
				{
					response.sendRedirect("ModifyJobStatus.jsp?status=pass");
				}
			}
			else
			{
				response.sendRedirect("Failure.jsp?status=You Have Entered InValid Job-ID");
			}
		
		}
		catch(Exception e)
		{
			out.println(e);
			response.sendRedirect("Failure.jsp?status=Failed to Modify Job");
		}
		
	}

}
