package myServlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import entitybeans.jobdetails;

/**
 * Servlet implementation class deleteJob
 */
@WebServlet("/deleteJob")
public class deleteJob extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public deleteJob() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		PrintWriter out= response.getWriter();
		response.setContentType("text/html");
		
		
		String jobid=request.getParameter("jobid");
		
		Configuration cfg=new Configuration().configure();
		SessionFactory sf=cfg.addAnnotatedClass(jobdetails.class).buildSessionFactory();
		Session ses=sf.getCurrentSession();
		ses.beginTransaction();

		Query q=ses.createQuery("delete jobdetails where jobid=:sh");
		q.setParameter("sh",jobid);
		int cnt=q.executeUpdate();
		ses.getTransaction().commit();

		if(cnt>0)
			out.println("<h3>Job is deleted</h3>");
		else
			out.println("<h3>Job is not deleted</h3>");
		
		
	}

}
