package myServlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import entitybeans.*;

/**
 * Servlet implementation class newUser
 */
@WebServlet("/newUser")
public class newUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public newUser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		PrintWriter out= response.getWriter();
		response.setContentType("text/html");
		
		String utype=request.getParameter("usertype");
		String userid=request.getParameter("uid");
		String email=request.getParameter("mail");
		String name=request.getParameter("name");
		String mobileno=request.getParameter("mobile");
		String question=request.getParameter("question");
		String answer=request.getParameter("answer");
		String pswd=request.getParameter("conpass");
		String usertype;
		
		try
		{
			if(utype.equals("Employer"))
				usertype="employer";
			else
				usertype="candidate";
			
			Configuration cfg=new Configuration().configure();
			SessionFactory sf=cfg.addAnnotatedClass(userlogin.class).buildSessionFactory();
			Session ses=sf.getCurrentSession();
			ses.beginTransaction();
			
			
		userlogin obj= new userlogin();
		obj.setUserid(userid);
		obj.setPswd(pswd);
		obj.setUsertype(usertype);
		
		ses.save(obj);
		ses.getTransaction().commit();
		
		}
		
		catch(Exception e)
		{
			out.println(e);
			response.sendRedirect("Failure.jsp");
		}
		
	
	
	try
	{
		Configuration cfg=new Configuration().configure();
		SessionFactory sf=cfg.addAnnotatedClass(usersdata.class).buildSessionFactory();
		Session ses=sf.getCurrentSession();
		ses.beginTransaction();
		
		usersdata object= new usersdata();
		object.setUserid(userid);
		object.setName(name);
		object.setEmail(email);
		object.setMobileno(mobileno);
		object.setQuestion(question);
		object.setAnswer(answer);
		
		ses.save(object);
		ses.getTransaction().commit();
		System.out.println("New User added to DataBase");
		
		HttpSession sessoinTracking=request.getSession(true);
		sessoinTracking.setAttribute("userid", userid);
		
		if(utype.equals("Employer"))
			response.sendRedirect("employer.jsp");
		else
			response.sendRedirect("candidate.jsp");
		
		
	}
	
	catch(Exception e)
	{
		out.println(e);
		response.sendRedirect("Failure.jsp");
	}
	
		
	}

}
