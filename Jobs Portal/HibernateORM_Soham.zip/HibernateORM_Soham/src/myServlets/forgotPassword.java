package myServlets;


import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.*;

import entitybeans.*;
/**
 * Servlet implementation class forgotPassword
 */
@WebServlet("/forgotPassword")
public class forgotPassword extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public forgotPassword() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		PrintWriter out= response.getWriter();
		response.setContentType("text/html");
		
		String userid=request.getParameter("uid");
		String question=request.getParameter("question");
		String answer=request.getParameter("answer");
		String email=request.getParameter("mail");
		String mobileno=request.getParameter("mobileno");
		
		
		try
		{
			Configuration cfg=new Configuration().configure();
			SessionFactory sf=cfg.addAnnotatedClass(usersdata.class).buildSessionFactory();
			Session ses=sf.getCurrentSession();
			ses.beginTransaction();
			
			Query q=ses.createQuery("from usersdata where userid =:uid and question= :que and answer= :ans and email= :mail and mobileno= :mobile");
			q.setParameter("uid", userid);
			q.setParameter("que", question);
			q.setParameter("ans", answer);
			q.setParameter("mail", email);
			q.setParameter("mobile", mobileno);
			
			List lst=q.getResultList();
			
			if(lst.size()>0)
			{
				response.sendRedirect("newPassword.jsp?userid="+userid);
			}
			else
			{
				response.sendRedirect("Failure.jsp");
			}
		}
		
		catch(Exception e)
		{
			out.println(e);
			response.sendRedirect("Failure.jsp");
		}
		
	}

}
