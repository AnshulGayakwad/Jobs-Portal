package myServlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import entitybeans.userlogin;

/**
 * Servlet implementation class newPassword
 */
@WebServlet("/newPassword")
public class newPassword extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public newPassword() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		PrintWriter out= response.getWriter();
		response.setContentType("text/html");
		
		String userid=request.getParameter("uid");
		String pswd=request.getParameter("npass");
		
		
		try
		{
			Configuration cfg=new Configuration().configure();
			SessionFactory sf=cfg.addAnnotatedClass(userlogin.class).buildSessionFactory();
			Session ses=sf.getCurrentSession();
			ses.beginTransaction();
			
			Query q=ses.createQuery("update userlogin set pswd= :pass where userid= :uid");
			q.setParameter("pass", pswd);
			q.setParameter("uid", userid);
			
			int cnt=q.executeUpdate();
			if(cnt>0)
				response.sendRedirect("index.jsp");
			else
				response.sendRedirect("Failure.jsp");
			
			ses.getTransaction().commit();
			ses.close();
		}
		
		catch(Exception e)
		{
			out.println(e);
			response.sendRedirect("Failure.jsp");
		}
	}

}
