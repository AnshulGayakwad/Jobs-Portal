package myServlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import entitybeans.userlogin;

/**
 * Servlet implementation class changePassword
 */
@WebServlet("/changePassword")
public class changePassword extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public changePassword() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		
		PrintWriter out= response.getWriter();
		response.setContentType("text/html");
		
		String userid=request.getParameter("uid");
		String currentpswd=request.getParameter("cpass");
		String newpswd=request.getParameter("conpass");
		System.out.println(userid);
		System.out.println(currentpswd);
		System.out.println(newpswd);
		
		try
		{

			Configuration cfg=new Configuration().configure();
			SessionFactory sf=cfg.addAnnotatedClass(userlogin.class).buildSessionFactory();
			Session ses=sf.getCurrentSession();
			ses.beginTransaction();
			
			Query q=ses.createQuery("from userlogin where userid= :uid and pswd= :pass");
			q.setParameter("uid", userid);
			q.setParameter("pass", currentpswd);
			
			List lst=q.getResultList();
			if(lst.size()>0)
			{
				
				Query qu=ses.createQuery("update userlogin set pswd= :npass where userid= :usid");
				qu.setParameter("npass", newpswd);
				qu.setParameter("usid", userid);
				int i=qu.executeUpdate();
				ses.getTransaction().commit();
				if(i>0)
				{
					response.sendRedirect("successchangePass.jsp");
				}
			}
			else
			{
				response.sendRedirect("Failure.jsp?status=Wrong Password ");
			}
			
		}
		catch(Exception e)
		{
			out.println(e);
			System.out.println("Catch "+userid);
			System.out.println("Catch "+currentpswd);
			System.out.println("Catch "+newpswd);
			response.sendRedirect("Failure.jsp?status=Failed to update Password");
		}
	}

}
