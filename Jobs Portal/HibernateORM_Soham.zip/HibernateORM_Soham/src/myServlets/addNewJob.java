package myServlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import entitybeans.jobdetails;
import entitybeans.userlogin;

/**
 * Servlet implementation class addNewJob
 */
@WebServlet("/addNewJob")
public class addNewJob extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public addNewJob() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		PrintWriter out= response.getWriter();
		response.setContentType("text/html");
		
		
		String jobid=request.getParameter("jobid");
		String jobname=request.getParameter("jobname");
		String location=request.getParameter("location");
		double packages=Double.parseDouble(request.getParameter("package"));
		String jobdate=request.getParameter("jobdate");
		String skills=request.getParameter("skills");
		String vacancy="yes";
	
		
		try
		{
			Configuration cfg=new Configuration().configure();
			SessionFactory sf=cfg.addAnnotatedClass(jobdetails.class).buildSessionFactory();
			Session ses=sf.getCurrentSession();
			ses.beginTransaction();
			
			System.out.print("current date given "+jobdate);
		jobdetails obj= new jobdetails();
//		
//		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
//		Date date = sdf.parse(jobdate);
//		
		
		obj.setJobid(jobid);
		obj.setJobname(jobname);
		obj.setLocation(location);
		obj.setPackages(packages);
		obj.setJobdate(jobdate);
		obj.setSkills(skills);
		obj.setVacancy(vacancy);
		
		ses.save(obj);
		ses.getTransaction().commit();
		
		System.out.println("coming date from jsp page "+jobdate);
		
		response.sendRedirect("employer.jsp?addstatus=done");
		}

		catch(Exception e)
		{
			out.println(e);
			System.out.print("current date given in catch "+jobdate);
			response.sendRedirect("Failure.jsp");
		}
	}

}
